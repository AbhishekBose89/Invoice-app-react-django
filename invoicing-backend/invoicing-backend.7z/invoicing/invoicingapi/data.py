users = [{"email": "abc@gmail.com","password":"abhishek"}]
invoices = [
    {
        "invoice_id": 1,
        "client_name": "person1",
        "date": "2023-06-01",
        "items": [
            {
                "desc": "Product A",
                "quantity": 2,
                "rate": 100,
            },
            {
                "desc": "Product B",
                "quantity": 1,
                "rate": 200,
            },
        ],
    },
    {
        "invoice_id": 2,
        "client_name": "person2",
        "date": "2023-05-31",
        "items": [
            {
                "desc": "Product A",
                "quantity": 5,
                "rate": 100,
            },
            {
                "desc": "Product C",
                "quantity": 3,
                "rate": 150,
            },
        ],
    },
    {
        "invoice_id": 3,
        "client_name": "person3",
        "date": "2023-05-30",
        "items": [
            {
                "desc": "Product B",
                "quantity": 2,
                "rate": 200,
            },
            {
                "desc": "Product D",
                "quantity": 1,
                "rate": 250,
            },
        ],
    },
]
